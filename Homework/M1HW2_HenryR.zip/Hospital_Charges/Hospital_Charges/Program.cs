﻿/**
* 1 September 2019
* CSC 253-0001
* Rashad Henry
* This program uses a console app to receive data from the user
* to store and calculate the total charges for a hospital bill
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hospital_Charges
{
    class Program
    {
        static void Main(string[] args)
        {
            // Title header
            Console.WriteLine("----------------------Hospital Charges App----------------------");
            // Each line asking for user input to store charge data
            Console.WriteLine("Enter the number of days spent in the hospital");
            double numOfDays = double.Parse(Console.ReadLine());

            Console.WriteLine("Enter the amount of medication charges");
            double medCharges = double.Parse(Console.ReadLine());

            Console.WriteLine("Enter the amount of surgical charges");
            double surgicalCharges = double.Parse(Console.ReadLine());

            Console.WriteLine("Enter the amount of lab fees");
            double labFee = double.Parse(Console.ReadLine());

            Console.WriteLine("Enter the amount of phyiscal rehab charges");
            double rehabCharges = double.Parse(Console.ReadLine());

            Console.WriteLine();

            // Calculate the total charges
            double calcStayCharges = numOfDays * 350.00;
            double calcMiscCharges = medCharges + surgicalCharges + labFee + rehabCharges;
            double totalCharges = calcStayCharges + calcMiscCharges;

            // Display charges
            Console.WriteLine("The total charges for your stay in the hospital is: " + calcStayCharges);
            Console.WriteLine("The total charges for meds, labs, surgical, and rehab is: " + calcMiscCharges);
            Console.WriteLine("The total sum of all your charges is: " + totalCharges);

            // Prevent console app from auto-closing
            Console.WriteLine();
            Console.WriteLine("Press any key to close the application");
            Console.ReadKey();
        }
        /*private double CalcStayCharges(double numOfDays)
        {
            return numOfDays * 350;
        }

        private double CalcMiscCharges(double medCharges, double surgCharges, double labFee, double rehabCharges)
        {
            return (medCharges + surgCharges + labFee + rehabCharges);
        }

        private double CalcTotalCharges(double numofDays, double medCharges, double surgCharges, double labFee, double rehabCharges)
        {
            return CalcStayCharges(numofDays) + CalcMiscCharges(medCharges, surgCharges, labFee, rehabCharges);
        }
    */}
}
