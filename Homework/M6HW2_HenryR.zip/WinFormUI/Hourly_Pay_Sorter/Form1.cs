﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 2 Dec 2019
* CSC 253
* Rashad Henry
* Program takes the Personnel database created in the previous assignment
* and is updated to include a form with buttons to sort the hourly pay rate
* data in ascending order and descending order. The user can return the data 
* in the DataGridView to its original state with the return button
*/

namespace Hourly_Pay_Sorter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void EmployeeBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.employeeBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.personnelDataSet);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'personnelDataSet.Employee' table. You can move, or remove it, as needed.
            this.employeeTableAdapter.Fill(this.personnelDataSet.Employee);

        }

        private void AscendSortButton_Click(object sender, EventArgs e)
        {
            // Click event to sort the DataGridView by hourly_pay_rate in ascending order
            this.employeeTableAdapter.FillByHourlyPayRateASC(this.personnelDataSet.Employee);
        }

        private void DescendSortButton_Click(object sender, EventArgs e)
        {
            // Click event to sort the DataGridView by hourly_pay_rate in descending order
            this.employeeTableAdapter.FillByHourlyPayRateDESC(this.personnelDataSet.Employee);
        }

        private void ReturnButton_Click(object sender, EventArgs e)
        {
            // Click event to sort the DataGridView by EmployeeID(Primary Key) which returns DataGridView to its original form
            this.employeeTableAdapter.FillByEmployeeID(this.personnelDataSet.Employee);
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            // Close the form
            this.Close();
        }
    }
}
