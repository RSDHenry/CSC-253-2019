﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Emp_ProdWorker_Classes
{
    class TeamLeader : ProductionWorker // TeamLeader class is derived from the ProductionWorker class
    {
        // Variable declaration
        private double monthlyBonusAmt;
        private double requiredTrainingHrs;
        private double trainingHrsAttended;

        public double MonthlyBonusAmt
        {
            // Get & Set for properties
            get
            {
                return monthlyBonusAmt;
            }
            set
            {
                monthlyBonusAmt = value;
            }
        }

        public double RequiredTrainingHrs
        {
            get
            {
                return requiredTrainingHrs;
            }
            set
            {
                requiredTrainingHrs = value;
            }
        }

        public double TrainingHrsAttended
        {
            get
            {
                return trainingHrsAttended;
            }
            set
            {
                trainingHrsAttended = value;
            }
        }

        public TeamLeader(int shiftNumber, double hourlyPayRate, double monthlyBonusAmt, double requiredTrainingHrs, double trainingHrsAttended) : base
            (shiftNumber, hourlyPayRate)
        {
            // Constructor for Team Leader Class
            this.monthlyBonusAmt = monthlyBonusAmt;
            this.requiredTrainingHrs = requiredTrainingHrs;
            this.trainingHrsAttended = trainingHrsAttended;
        }

        public string toString()
        {
            return base.toString() + "\nTeam Leader Monthly Bonus Amount: $" + monthlyBonusAmt + "Team Leader Required Training Hours: " + requiredTrainingHrs
                + "Team Leader Training Hours Attended: " + trainingHrsAttended;
        }
    }
}
