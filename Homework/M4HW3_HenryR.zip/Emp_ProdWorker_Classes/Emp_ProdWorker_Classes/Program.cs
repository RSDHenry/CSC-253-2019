﻿/**
* 27 October 2019
* CSC 253
* Rashad Henry
* This program uses three classes (two of them deriving from the employee
* class to take user input and create a new object. When done the program
* should display the input back to the user. 
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Emp_ProdWorker_Classes
{
    class Program
    {
        static void Main(string[] args)
        {
            // Gather input for data to create production worker
            Console.WriteLine("Enter the name of the Team Leader: ");
            string employeeName = Console.ReadLine();

            Console.WriteLine("Enter the employee number: ");
            int employeeNumber = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the shift number: ");
            int shiftNumber = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the hourly pay rate: ");
            double hourlyPayRate = Convert.ToDouble(Console.ReadLine());

            /*Console.WriteLine("Enter the annual salary for the shift supervisor: ");
            double annualSalary = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter the annual bonus for the shift supervisor: ");
            double annualBonus = Convert.ToDouble(Console.ReadLine());*/

            Console.WriteLine("Enter the monthly bonus amount: ");
            double monthlyBonusAmt = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter the required training hours: ");
            double requiredTrainingHrs = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter the amount of training hours attended: ");
            double trainingHrsAttended = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine();

            // Creation of a new Production Worker / Shift Supervisor/ Team Leader
            ProductionWorker prodWorker = new ProductionWorker(employeeName, employeeNumber, shiftNumber, hourlyPayRate);
            //ShiftSupervisor shiftSup = new ShiftSupervisor(employeeName, employeeNumber, annualSalary, annualBonus);
            TeamLeader teamLead = new TeamLeader(shiftNumber, hourlyPayRate, monthlyBonusAmt, requiredTrainingHrs, trainingHrsAttended);

            // Output display
            Console.WriteLine("Team Leader: " + teamLead.EmployeeName);
            Console.WriteLine("Employee Number: " + teamLead.EmployeeNumber);
            Console.WriteLine("Shift Number: " + teamLead.ShiftNumber);
            Console.WriteLine("Hourly Pay Rate: $" + teamLead.HourlyPayRate);
            Console.WriteLine("Monthly Bonus Amount: $" + teamLead.MonthlyBonusAmt);
            Console.WriteLine("Required Training Hours: " + teamLead.RequiredTrainingHrs);
            Console.WriteLine("Training Hours Attended: " + teamLead.TrainingHrsAttended);
            //Console.WriteLine("Shift Supervisor annual salary: $" + shiftSup.AnnualSalary);
            //Console.WriteLine("Shift Supervisor annual bonus: $" + shiftSup.AnnualBonus);
            Console.WriteLine();
            Console.WriteLine("Press any key to close the console.");
            Console.ReadKey();
        }
    }
}
