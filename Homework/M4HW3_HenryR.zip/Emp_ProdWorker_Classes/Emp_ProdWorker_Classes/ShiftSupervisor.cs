﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Emp_ProdWorker_Classes
{
    class ShiftSupervisor : Employee // Shift Supervisor class is derived from the Employee class
    {
        // Variable declaration
        private double annualSalary;
        private double annualBonus;

        public double AnnualSalary
        {
            // Get & Set for properties
            get
            {
                return annualSalary;
            }
            set
            {
                annualSalary = value;
            }
        }

        public double AnnualBonus
        {
            get
            {
                return annualBonus;
            }
            set
            {
                annualBonus = value;
            }
        }

        public ShiftSupervisor(string employeeName, int employeeNumber, double annualSalary, double annualBonus) : base(employeeName, employeeNumber)
            // Constructor for Shift Supervisor class
        {
            this.annualSalary = annualSalary;
            this.annualBonus = annualBonus;
        }

        public string toString()
        {
            return base.toString() + "\nShift Supervisor Annual Salary: $" + annualSalary + "Shift Supervisor Annual Bonus: $" + annualBonus;
        }
    }
}
