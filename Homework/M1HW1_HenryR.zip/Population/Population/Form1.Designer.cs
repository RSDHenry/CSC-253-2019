﻿namespace Population
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.numOfOrganismsTextBox = new System.Windows.Forms.TextBox();
            this.dailyIncreaseTextBox = new System.Windows.Forms.TextBox();
            this.numOfOrganismsLabel = new System.Windows.Forms.Label();
            this.dailyIncreaseLabel = new System.Windows.Forms.Label();
            this.daysToMultiplyTextBox = new System.Windows.Forms.TextBox();
            this.daysToMultiplyLabel = new System.Windows.Forms.Label();
            this.calculateButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.populationListBox = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // numOfOrganismsTextBox
            // 
            this.numOfOrganismsTextBox.Location = new System.Drawing.Point(211, 38);
            this.numOfOrganismsTextBox.Name = "numOfOrganismsTextBox";
            this.numOfOrganismsTextBox.Size = new System.Drawing.Size(100, 20);
            this.numOfOrganismsTextBox.TabIndex = 0;
            // 
            // dailyIncreaseTextBox
            // 
            this.dailyIncreaseTextBox.Location = new System.Drawing.Point(211, 64);
            this.dailyIncreaseTextBox.Name = "dailyIncreaseTextBox";
            this.dailyIncreaseTextBox.Size = new System.Drawing.Size(100, 20);
            this.dailyIncreaseTextBox.TabIndex = 1;
            // 
            // numOfOrganismsLabel
            // 
            this.numOfOrganismsLabel.AutoSize = true;
            this.numOfOrganismsLabel.Location = new System.Drawing.Point(55, 41);
            this.numOfOrganismsLabel.Name = "numOfOrganismsLabel";
            this.numOfOrganismsLabel.Size = new System.Drawing.Size(150, 13);
            this.numOfOrganismsLabel.TabIndex = 6;
            this.numOfOrganismsLabel.Text = "Starting Number of Organisms:";
            // 
            // dailyIncreaseLabel
            // 
            this.dailyIncreaseLabel.AutoSize = true;
            this.dailyIncreaseLabel.Location = new System.Drawing.Point(85, 67);
            this.dailyIncreaseLabel.Name = "dailyIncreaseLabel";
            this.dailyIncreaseLabel.Size = new System.Drawing.Size(120, 13);
            this.dailyIncreaseLabel.TabIndex = 7;
            this.dailyIncreaseLabel.Text = "Average Daily Increase:";
            // 
            // daysToMultiplyTextBox
            // 
            this.daysToMultiplyTextBox.Location = new System.Drawing.Point(211, 90);
            this.daysToMultiplyTextBox.Name = "daysToMultiplyTextBox";
            this.daysToMultiplyTextBox.Size = new System.Drawing.Size(100, 20);
            this.daysToMultiplyTextBox.TabIndex = 8;
            // 
            // daysToMultiplyLabel
            // 
            this.daysToMultiplyLabel.AutoSize = true;
            this.daysToMultiplyLabel.Location = new System.Drawing.Point(69, 93);
            this.daysToMultiplyLabel.Name = "daysToMultiplyLabel";
            this.daysToMultiplyLabel.Size = new System.Drawing.Size(136, 13);
            this.daysToMultiplyLabel.TabIndex = 9;
            this.daysToMultiplyLabel.Text = "Number of Days to Multiply:";
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(74, 365);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(75, 23);
            this.calculateButton.TabIndex = 10;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.CalculateButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(155, 365);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 11;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.ClearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(236, 365);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 12;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // populationListBox
            // 
            this.populationListBox.FormattingEnabled = true;
            this.populationListBox.Location = new System.Drawing.Point(58, 136);
            this.populationListBox.Name = "populationListBox";
            this.populationListBox.Size = new System.Drawing.Size(253, 199);
            this.populationListBox.TabIndex = 13;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(383, 400);
            this.Controls.Add(this.populationListBox);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.daysToMultiplyLabel);
            this.Controls.Add(this.daysToMultiplyTextBox);
            this.Controls.Add(this.dailyIncreaseLabel);
            this.Controls.Add(this.numOfOrganismsLabel);
            this.Controls.Add(this.dailyIncreaseTextBox);
            this.Controls.Add(this.numOfOrganismsTextBox);
            this.Name = "Form1";
            this.Text = "Population of Organism";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox numOfOrganismsTextBox;
        private System.Windows.Forms.TextBox dailyIncreaseTextBox;
        private System.Windows.Forms.Label numOfOrganismsLabel;
        private System.Windows.Forms.Label dailyIncreaseLabel;
        private System.Windows.Forms.TextBox daysToMultiplyTextBox;
        private System.Windows.Forms.Label daysToMultiplyLabel;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.ListBox populationListBox;
    }
}

