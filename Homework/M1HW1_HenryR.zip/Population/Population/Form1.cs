﻿/**
* 1 September 2019
* CSC 253-0001
* Rashad Henry
* This program uses a form to take valid 
* user input and calculate the population
* of organisms
*/
using System;
using System.Windows.Forms;

namespace Population
{
    public partial class Form1 : System.Windows.Forms.Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void CalculateButton_Click(object sender, EventArgs e)
        {

            // Variables.
            int count = 1;


            // Loop will convert the string input from user in the textboxes to doubles and integers type.
            if (double.TryParse(numOfOrganismsTextBox.Text, out double numOfOrganism)
                && double.TryParse(dailyIncreaseTextBox.Text, out double dailyIncrease)
                && int.TryParse(daysToMultiplyTextBox.Text, out int numOfDays))
            {
                _ = populationListBox.Items.Add("Day             Approximate Population");
                // This statement ensures that the dailyIncrease is considered as a percentage.
                dailyIncrease /= 100;

                while (count <= numOfDays)
                {
                    // Prints out the initial value.
                    populationListBox.Items.Add(count + "                       " + numOfOrganism);
                    // Add one to the loop counter.
                    count += 1;
                    // Perform calculation for the population.
                    numOfOrganism += numOfOrganism * dailyIncrease;
                }

            }
            else
            {
                // If input is invalid then display this message
                MessageBox.Show("Invalid input.");
            }
        }

        private void ClearButton_Click(object sender, EventArgs e)
        {
            // Clear out all user input in the listbox
            populationListBox.Items.Clear();
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            // Close the form
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
