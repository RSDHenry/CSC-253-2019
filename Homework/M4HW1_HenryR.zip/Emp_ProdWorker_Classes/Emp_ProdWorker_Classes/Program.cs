﻿/**
* 27 October 2019
* CSC 253
* Rashad Henry
* This program uses two classes (one of them deriving from the other
* to take user input and create a new object. When done the program
* should display the input back to the user. 
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Emp_ProdWorker_Classes
{
    class Program
    {
        static void Main(string[] args)
        {
            // Gather input for data to create production worker
            Console.WriteLine("Enter the name of the employee: ");
            string employeeName = Console.ReadLine();

            Console.WriteLine("Enter the employee number: ");
            int employeeNumber = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the shift number: ");
            int shiftNumber = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the hourly pay rate: ");
            double hourlyPayRate = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine();

            // Creation of a new Production Worker
            ProductionWorker prodWorker = new ProductionWorker(employeeName, employeeNumber, shiftNumber, hourlyPayRate);

            // Output display
            Console.WriteLine("Employee Name: " + prodWorker.EmployeeName);
            Console.WriteLine("Employee Number: " + prodWorker.EmployeeNumber);
            Console.WriteLine("Shift Number: " + prodWorker.ShiftNumber);
            Console.WriteLine("Hourly Pay Rate: " + prodWorker.HourlyPayRate);
            Console.WriteLine();
            Console.WriteLine("Press any key to close the console.");
            Console.ReadKey();
        }
    }
}
