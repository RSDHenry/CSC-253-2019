﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Emp_ProdWorker_Classes
{
    public class Employee
    {
        // Variable declaration
        private string employeeName;
        private int employeeNumber;

        public string EmployeeName
        {
            // Get & Set for properties
            get
            {
                return employeeName;
            }
            set
            {
                employeeName = value;
            }
        }

        public int EmployeeNumber
        {
            get
            {
                return employeeNumber;
            }
            set
            {
                employeeNumber = value;
            }
        }

        public Employee(string employeeName, int employeeNumber) // Constructor the Employee Class
        {
            this.employeeName = employeeName;
            this.employeeNumber = employeeNumber;
        }

        public string toString()
        {
            return "\nEmployee Name: " + employeeName + "Employee Number: " + employeeNumber;
        }
    }
}

