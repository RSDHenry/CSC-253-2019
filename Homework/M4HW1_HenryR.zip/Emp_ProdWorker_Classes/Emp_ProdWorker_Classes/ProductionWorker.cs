﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Emp_ProdWorker_Classes
{
    class ProductionWorker : Employee // Production Worker is derived from the Employee class
    {
        private int shiftNumber;
        private double hourlyPayRate;

        public int ShiftNumber
        {
            // Get & Set for properties 
            get
            {
                return shiftNumber;
            }
            set
            {
                shiftNumber = value;
            }
        }

        public double HourlyPayRate
        {
            get
            {
                return hourlyPayRate;
            }
            set
            {
                hourlyPayRate = value;
            }
        }

        public ProductionWorker(string employeeName, int employeeNumber, int shiftNumber, double hourlyPayRate):base(employeeName, employeeNumber) // Constructor
        {
            this.shiftNumber = shiftNumber;
            this.hourlyPayRate = hourlyPayRate;
        }

        public string toString()
        {
            return base.toString() + "\nShift Number: " + shiftNumber + "Hourly Pay Rate: $" + hourlyPayRate;
        }
    }
}
