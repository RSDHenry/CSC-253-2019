﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
/**
* 1 Oct 2019
* CSC 253
* Rashad Henry
* C# Console Application that creates a streamwriter to take user input
* and generate a file with a listing of random numbers that will iterate 
* by the users specific number.
*/

namespace Random_Number_File_Writer
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                /**
                 * The application will create a new file and write to it and the file is stored 
                 * the application folder under bin -> Debug -> filename (RandomNumbers.txt)
                 */
                // Application Welcome Title
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("------------Welcome to the Random Number File Writer App------------");
                Console.ResetColor();

                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("Please enter the number of random numbers for the file to hold: ");
                Console.ResetColor();
                int userNumber = int.Parse(Console.ReadLine());

                // Creation of the random class obj
                Random random = new Random();
                // random number variable and initialization
                int randomNumber = 0;
                
                // Creation of StreamWriter and output file with the name RandomNumbers.txt
                StreamWriter outputFile = File.CreateText("RandomNumbers.txt");
                while (userNumber > 0)
                {
                    // Random number range between ints 1-100
                    randomNumber = random.Next(1, 101);
                    // Write the random numbers to the output file
                    outputFile.WriteLine(randomNumber.ToString());

                    userNumber--;
                }
                // Close the file
                outputFile.Close();

                // Closing message to the user.
                Console.WriteLine();
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("Thank you. Press any key to close the application.");
                Console.ReadKey();

            }
            catch (Exception)
            {
                // Display an error message
                Console.Error.WriteLine();
            }
        }
    }
}
