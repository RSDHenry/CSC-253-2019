﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 3 Dec 2019
* CSC 253
* Rashad Henry
* This program takes the personnel database built from the previous assignment
* and is attached to a form to display data in a DataGridView.
* The form has buttons to allow the user to search the Database for
* an employee by name and the results of that search are displayed 
* back to the user.
*/

namespace WinFormUI
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void employeeBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.employeeBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.personnelDataSet);

        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'personnelDataSet.Employee' table. You can move, or remove it, as needed.
            this.employeeTableAdapter.Fill(this.personnelDataSet.Employee);

        }

        private void searchEmpButton_Click(object sender, EventArgs e)
        {
            // Display an error message if the user trys to conduct a search without any data entered into the empSearchTxtBox
            if (empSearchTxtBox.Text == "")
            {
                MessageBox.Show("Error: Can't conduct search with an empty search box!");
            }
            else 
            // Takes the userInput and searches the Database for any full or partial matches then
            // displays any matching rows
            this.employeeTableAdapter.SearchByEmpName(this.personnelDataSet.Employee, empSearchTxtBox.Text);
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // Clear the contents of the empSearchTxtBox
            empSearchTxtBox.Clear();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close the form
            this.Close();
        }

        private void resetButton_Click(object sender, EventArgs e)
        {
            // Reset the DataGridView to display all rows in original sort
            this.employeeTableAdapter.FillByEmployeeID(this.personnelDataSet.Employee);
        }
    }
}
