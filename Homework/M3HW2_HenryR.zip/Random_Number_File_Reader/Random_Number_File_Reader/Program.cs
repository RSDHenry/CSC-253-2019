﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;
using System.Diagnostics;
/**
* 2 Oct 2019
* CSC 253
* Rashad Henry
* This console application will allow you (using a openFileDialog control)
* to search for a file on the machine and open the file.
* The program will then read the contents of the file 
* and perform a calculation and display the results.
* For the sake of this demonstration, please search for the "RandomNumbers.txt"
* file in the debug folder of the Random Number File Writer program.
*/

namespace Random_Number_File_Reader
{
    class Program
    {
        [STAThread]
        /* STAThread allows the console to communicate with COM components.
         * STATthread and using System.Windows.Forms and System.Diagnostics 
         * are needed for this console application to use the OpenFileDialog 
         * control
         */
        static void Main(string[] args)
        {
            try
            {
                // Console application title and greeting
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("------------Welcome to the Random Number File Reader------------");
                Console.ResetColor();

                // Variable declaration
                int count = 0;
                int numbers = 0;
                int sumOfNumbers = 0;

                // Creation of a OpenFileDialog control
                OpenFileDialog openFileDialog = new OpenFileDialog();
                openFileDialog.ShowDialog();

                string filePath = openFileDialog.FileName;

                // Creation of a StreamReader control to read from a specified file
                StreamReader inputFile = new StreamReader(filePath);

                // While loop will read the contents of the selected file convert the data into int type for calculation
                while (!inputFile.EndOfStream)
                {
                    numbers = Convert.ToInt32(inputFile.ReadLine());
                    sumOfNumbers += numbers;

                    count++;
                }

                /* Displays the total of all the random numbers in the file
                // and will display the total number of random numbers that were 
                // in the file
                // Next time I'll write a method to handle all the coloring
                */
                Console.Write("The total of the numbers is: ");
                Console.ForegroundColor = ConsoleColor.Red;
                Console.BackgroundColor = ConsoleColor.Black;
                Console.WriteLine(sumOfNumbers);
                Console.ResetColor();
                Console.Write("The number of random numbers read from the file is: ");
                Console.ForegroundColor = ConsoleColor.Red;
                Console.BackgroundColor = ConsoleColor.Black;
                Console.WriteLine(count);
                Console.ResetColor();

                Console.WriteLine();
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("Thank you. Enter any key to close the application.");
                Console.ReadKey(); // Keep the console application from auto closing
            }
            catch (Exception)
            {
                Console.Error.WriteLine();
            }
        }
    }
}
