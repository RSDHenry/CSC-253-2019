﻿namespace CarClass
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.yearLabel = new System.Windows.Forms.Label();
            this.makeLabel = new System.Windows.Forms.Label();
            this.speedLabel = new System.Windows.Forms.Label();
            this.accelerateButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.brakeButton = new System.Windows.Forms.Button();
            this.displayYearLabel = new System.Windows.Forms.Label();
            this.displayMakeLabel = new System.Windows.Forms.Label();
            this.displaySpeedLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // yearLabel
            // 
            this.yearLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.yearLabel.Location = new System.Drawing.Point(44, 67);
            this.yearLabel.Name = "yearLabel";
            this.yearLabel.Size = new System.Drawing.Size(100, 23);
            this.yearLabel.TabIndex = 0;
            this.yearLabel.Text = "Year:";
            // 
            // makeLabel
            // 
            this.makeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.makeLabel.Location = new System.Drawing.Point(44, 106);
            this.makeLabel.Name = "makeLabel";
            this.makeLabel.Size = new System.Drawing.Size(100, 23);
            this.makeLabel.TabIndex = 1;
            this.makeLabel.Text = "Make:";
            // 
            // speedLabel
            // 
            this.speedLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.speedLabel.Location = new System.Drawing.Point(44, 142);
            this.speedLabel.Name = "speedLabel";
            this.speedLabel.Size = new System.Drawing.Size(100, 23);
            this.speedLabel.TabIndex = 2;
            this.speedLabel.Text = "Speed:";
            // 
            // accelerateButton
            // 
            this.accelerateButton.Location = new System.Drawing.Point(49, 216);
            this.accelerateButton.Name = "accelerateButton";
            this.accelerateButton.Size = new System.Drawing.Size(95, 41);
            this.accelerateButton.TabIndex = 3;
            this.accelerateButton.Text = "Accelerate";
            this.accelerateButton.UseVisualStyleBackColor = true;
            this.accelerateButton.Click += new System.EventHandler(this.accelerateButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(99, 263);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(95, 41);
            this.exitButton.TabIndex = 4;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // brakeButton
            // 
            this.brakeButton.Location = new System.Drawing.Point(150, 216);
            this.brakeButton.Name = "brakeButton";
            this.brakeButton.Size = new System.Drawing.Size(95, 41);
            this.brakeButton.TabIndex = 5;
            this.brakeButton.Text = "Brake";
            this.brakeButton.UseVisualStyleBackColor = true;
            this.brakeButton.Click += new System.EventHandler(this.BrakeButton_Click);
            // 
            // displayYearLabel
            // 
            this.displayYearLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.displayYearLabel.Location = new System.Drawing.Point(108, 67);
            this.displayYearLabel.Name = "displayYearLabel";
            this.displayYearLabel.Size = new System.Drawing.Size(100, 23);
            this.displayYearLabel.TabIndex = 6;
            this.displayYearLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // displayMakeLabel
            // 
            this.displayMakeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.displayMakeLabel.Location = new System.Drawing.Point(108, 106);
            this.displayMakeLabel.Name = "displayMakeLabel";
            this.displayMakeLabel.Size = new System.Drawing.Size(100, 23);
            this.displayMakeLabel.TabIndex = 7;
            this.displayMakeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // displaySpeedLabel
            // 
            this.displaySpeedLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.displaySpeedLabel.Location = new System.Drawing.Point(109, 142);
            this.displaySpeedLabel.Name = "displaySpeedLabel";
            this.displaySpeedLabel.Size = new System.Drawing.Size(100, 23);
            this.displaySpeedLabel.TabIndex = 8;
            this.displaySpeedLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(293, 316);
            this.Controls.Add(this.displaySpeedLabel);
            this.Controls.Add(this.displayMakeLabel);
            this.Controls.Add(this.displayYearLabel);
            this.Controls.Add(this.brakeButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.accelerateButton);
            this.Controls.Add(this.speedLabel);
            this.Controls.Add(this.makeLabel);
            this.Controls.Add(this.yearLabel);
            this.Name = "MainForm";
            this.Text = "Simulate Acceleration and Braking";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label yearLabel;
        private System.Windows.Forms.Label makeLabel;
        private System.Windows.Forms.Label speedLabel;
        private System.Windows.Forms.Button accelerateButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button brakeButton;
        private System.Windows.Forms.Label displayYearLabel;
        private System.Windows.Forms.Label displayMakeLabel;
        private System.Windows.Forms.Label displaySpeedLabel;
    }
}

