﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarClass
{
    class Car
    {
        // Fields for the Car class.
        private int _year;
        private string _make;
        private int _speed;

        // Constructor to set the car's year, make, speed.
        public Car(int year, string make)
        {
            _year = year;
            _make = make;
            _speed = 0;
        }

        // Get & Set for Year Property.
        public int Year
        {
            get { return _year; }
            set { _year = value; }
        }

        // Get & Set for Make Property.
        public string Make
        {
            get { return _make; }
            set { _make = value; }
        }

        // Get & Set for Speed Property.
        public int Speed
        {
            get { return _speed; }
            set { _speed = value; }
        }

        // Take the car speed and accerlerate the speed property by 5.
        public void Accelerate()
        {
            _speed += 5;
        }

        // Take the car speed and decrease it (Braking) by -5.
        public void Brake()
        {
            _speed -= 5;
        }
    }
}
