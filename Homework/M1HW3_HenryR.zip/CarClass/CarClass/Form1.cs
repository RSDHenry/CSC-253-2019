﻿/**
* 1 September 2019
* CSC 253-0001
* Rashad Henry
* This program uses a Car Class to create a Car object
* to allow the user to increase and/or decrease the speed of the
* car.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarClass
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }
        // Create a new Car Class Object with the year of the car and make of the car for starting point.
        private readonly Car car = new Car(2020, "Bugatti Chiron");

        private void MainForm_Load(object sender, EventArgs e)
        {
            // Method to display the year, make, and speed of a car when the form loads.
            displayYearLabel.Text = car.Year.ToString();
            displayMakeLabel.Text = car.Make;
            displaySpeedLabel.Text = car.Speed.ToString();
        }

        private void accelerateButton_Click(object sender, EventArgs e)
        {
            // Call the acclerate method to increase the speed by +5.
            car.Accelerate();
            // Update the display speed label to reflect the increase in speed.
            displaySpeedLabel.Text = car.Speed.ToString("0");
        }

        private void BrakeButton_Click(object sender, EventArgs e)
        {
            // Call the brake method to decrease the speed by -5.
            // Using a If statement to validate the speed.
            if (car.Speed == 0)
                MessageBox.Show("Error, Your speed is 0. Please accelerate.");
            else
            {
                // After checking for validation, call the brake method and update the speed by -5.
                car.Brake();
                displaySpeedLabel.Text = car.Speed.ToString("0");
            }
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            // Close the form.
            this.Close();
        }
    }
}
