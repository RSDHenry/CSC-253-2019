﻿/**
* 1 September 2019
* CSC 253-0001
* Rashad Henry
* Using a class to display 
* retail items, number of units, and prices for each.
*/

namespace Retail_Item
{
    class RetailItem
    {
        // Properties declaration
        public string Description;
        public int UnitsOnHand;
        public double Price;

        // Create constructor and accept arguments for each property
        public RetailItem(string description, int unitsOnHand, double price)
        {
            // Define the object properties
            Description = description;
            UnitsOnHand = unitsOnHand;
            Price = price;
        }
    }
}
