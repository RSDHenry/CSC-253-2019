﻿/**
* 1 September 2019
* CSC 253-0001
* Rashad Henry
* Program demonstrates using a class and form load event to
* display retail items, number of units, and prices for each.
*/
using System;
using System.Windows.Forms;

namespace Retail_Item
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            // Create an object of Retail Item Class
            RetailItem[] obj = new RetailItem[3];

            // Creation of three instances of Retail Item Class and define objects
            obj[0] = new RetailItem("Jacket", 12, 59.95);
            obj[1] = new RetailItem("Jeans", 40, 34.95);
            obj[2] = new RetailItem("Shirt", 20, 24.95);

            // For loop to progress through the array
            for (int index = 0; index < obj.Length; index++)
            {
                // Add the items to the List Box
                // Using c formatter instead of f2 to display price output with a dollar sign included
                itemsListBox.Items.Add("Item " + (index + 1) + "\t\t" + obj[index].Description + "\t\t\t"
                    + obj[index].UnitsOnHand + "\t\t" + obj[index].Price.ToString("c"));
            }
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            // Close the form
            this.Close();
        }
    }
}