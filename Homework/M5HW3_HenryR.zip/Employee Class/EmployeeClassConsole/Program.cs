﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeClassLib;

/**
* 14 November 2019
* CSC 253
* Rashad Henry
* This program adds a console application and class library to the completed 
* form project. You can select to startup either as the form or the console
* to run the application
* The current startup is set as the console. 
*/

namespace EmployeeClassConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            // Creation of three employee objects
            Employee employee1 = new Employee("Susan Meyers", 47889, "Accounting", "Vice President");
            Employee employee2 = new Employee("Mark Jones", 39199, "IT", "Programmer");
            Employee employee3 = new Employee("Joy Rogers", 81774, "Manufacturing", "Engineer");

            // Application title header
            Console.ForegroundColor = ConsoleColor.Green;
            Console.BackgroundColor = ConsoleColor.Black;
            Console.WriteLine("Employee Name--ID #--Department--Position");
            Console.ResetColor();

            // Blank line for readability
            Console.WriteLine();

            // Display the employee information to the console
            Console.WriteLine(employee1.Name + ", " + employee1.idNumber + ", " + employee1.Department + ", " + employee1.Position);
            Console.WriteLine(employee2.Name + ", " + employee2.idNumber + ", " + employee2.Department + ", " + employee2.Position);
            Console.WriteLine(employee3.Name + ", " + employee3.idNumber + ", " + employee3.Department + ", " + employee3.Position);

            // Blank line for readability 
            Console.WriteLine();

            // ReadKey to keep console open until user enters any command
            Console.WriteLine("Press Any Key To Close The Console");
            Console.ReadKey();
        }   
    }
}