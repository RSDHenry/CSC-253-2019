﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DungeonCrawlerLibrary
{
    // enums used to validate if the player choose a character Race option.
    public enum Race
    {
        Elf, 

        Human,

        Dwarf,

        Orc,
    }
}
